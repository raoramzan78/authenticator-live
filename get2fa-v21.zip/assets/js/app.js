(() => {
  const menuButton = document.querySelector('.menu-button');
  const navigation = document.querySelector('.site-nav');
  if (menuButton && navigation) {
    menuButton.addEventListener('click', () => {
      const isOpen = navigation.classList.toggle('is-open');
      menuButton.setAttribute('aria-expanded', String(isOpen));
      menuButton.setAttribute('aria-label', isOpen ? 'Close menu' : 'Open menu');
    });
  }

  /* Dark / light theme toggle (saved on this device only) */
  const root = document.documentElement;
  function savedTheme() {
    try { return window.localStorage.getItem('authlive.theme'); } catch { return null; }
  }
  function applyTheme(theme) {
    if (theme === 'dark') root.setAttribute('data-theme', 'dark');
    else root.removeAttribute('data-theme');
  }
  applyTheme(savedTheme() || (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'));

  const headerInner = document.querySelector('.header-inner');
  if (headerInner) {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'theme-toggle';
    btn.setAttribute('aria-label', 'Switch dark or light mode');
    const paint = () => { btn.textContent = root.getAttribute('data-theme') === 'dark' ? '☀️' : '🌙'; };
    paint();
    btn.addEventListener('click', () => {
      const next = root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
      applyTheme(next);
      try { window.localStorage.setItem('authlive.theme', next); } catch { /* private mode */ }
      paint();
    });
    headerInner.appendChild(btn);
  }
})();
