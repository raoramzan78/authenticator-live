/* Authenticator Live — animation helpers (progressive enhancement only). */
(() => {
  const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  // Code pop: whenever the generated code text changes, pop it once.
  const code = document.querySelector('.generated-code');
  if (code && !reduce) {
    new MutationObserver(() => {
      if (!code.textContent.trim()) return;
      code.classList.remove('pop');
      void code.offsetWidth; // restart animation
      code.classList.add('pop');
    }).observe(code, { childList: true, characterData: true, subtree: true });
    code.addEventListener('animationend', () => code.classList.remove('pop'));
  }

  if (reduce || !('IntersectionObserver' in window)) return;

  // Scroll reveal for content sections & FAQ items (never the tool itself).
  const tool = document.querySelector('#secret-key');
  const toolSection = tool ? tool.closest('section') : null;
  const targets = [...document.querySelectorAll('section, .faq-item')]
    .filter((el) => el !== toolSection && !el.contains(tool));
  if (!targets.length) return;

  const io = new IntersectionObserver((entries) => {
    for (const e of entries) {
      if (e.isIntersecting) { e.target.classList.add('on'); io.unobserve(e.target); }
    }
  }, { threshold: 0.1 });

  for (const el of targets) {
    const r = el.getBoundingClientRect();
    if (r.top < window.innerHeight && r.bottom > 0) continue; // already visible: leave as-is
    el.classList.add('rv');
    io.observe(el);
  }
})();
