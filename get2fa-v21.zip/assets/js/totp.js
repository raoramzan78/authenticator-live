(() => {
  'use strict';

  /* ============ Core TOTP engine (RFC 4226 / RFC 6238) ============ */
  const HASH_NAMES = { SHA1: 'SHA-1', SHA256: 'SHA-256', SHA512: 'SHA-512' };

  function normaliseSecret(rawSecret) {
    return String(rawSecret || '').replace(/[\s-]/g, '').toUpperCase();
  }

  function decodeBase32(normalisedSecret) {
    const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    const lookup = new Map([...alphabet].map((c, i) => [c, i]));
    let bits = 0, bitsCount = 0;
    const bytes = [];
    for (const character of normalisedSecret) {
      if (character === '=') continue;
      const value = lookup.get(character);
      if (value === undefined) {
        throw new Error('That key contains invalid characters. Use letters A-Z and numbers 2-7 only.');
      }
      bits = (bits << 5) | value;
      bitsCount += 5;
      if (bitsCount >= 8) { bitsCount -= 8; bytes.push((bits >> bitsCount) & 0xff); }
    }
    if (bytes.length < 10) {
      throw new Error('That key is too short. Please enter the complete authentication secret key.');
    }
    return new Uint8Array(bytes);
  }

  function parseOtpAuth(rawValue) {
    const value = (rawValue || '').trim();
    const out = { secret: value, issuer: '', label: '', algorithm: null, digits: null, period: null, counter: null, type: 'totp' };
    if (/^otpauth:\/\//i.test(value)) {
      try {
        const u = new URL(value);
        const secret = u.searchParams.get('secret');
        if (secret) out.secret = secret;
        out.issuer = u.searchParams.get('issuer') || '';
        const path = decodeURIComponent(u.pathname).replace(/^\/+/, '');
        out.label = path || '';
        if (!out.issuer && out.label.includes(':')) out.issuer = out.label.split(':')[0].trim();
        const alg = (u.searchParams.get('algorithm') || '').replace('-', '').toUpperCase();
        if (HASH_NAMES[alg]) out.algorithm = alg;
        const d = parseInt(u.searchParams.get('digits') || '', 10);
        if (d === 6 || d === 8) out.digits = d;
        const p = parseInt(u.searchParams.get('period') || '', 10);
        if (p >= 10 && p <= 300) out.period = p;
        const ctr = parseInt(u.searchParams.get('counter') || '', 10);
        if (!Number.isNaN(ctr) && ctr >= 0) out.counter = ctr;
        out.type = (u.hostname || 'totp').toLowerCase();
      } catch { /* not parseable — fall through with raw value */ }
    }
    return out;
  }

  function counterBytes(counter) {
    const buf = new ArrayBuffer(8);
    const view = new DataView(buf);
    view.setUint32(0, Math.floor(counter / 0x100000000));
    view.setUint32(4, counter >>> 0);
    return buf;
  }

  async function generateCode(secretNorm, opts = {}) {
    const algorithm = HASH_NAMES[opts.algorithm] ? opts.algorithm : 'SHA1';
    const digits = opts.digits === 8 ? 8 : 6;
    const period = opts.period >= 10 && opts.period <= 300 ? opts.period : 30;
    const at = typeof opts.at === 'number' ? opts.at : Date.now();
    const secretBytes = decodeBase32(secretNorm);
    const counter = typeof opts.counter === 'number' ? opts.counter : Math.floor(at / 1000 / period);
    const key = await window.crypto.subtle.importKey('raw', secretBytes, { name: 'HMAC', hash: HASH_NAMES[algorithm] }, false, ['sign']);
    const digest = new Uint8Array(await window.crypto.subtle.sign('HMAC', key, counterBytes(counter)));
    const offset = digest[digest.length - 1] & 0x0f;
    const binary = ((digest[offset] & 0x7f) << 24) | ((digest[offset + 1] & 0xff) << 16) | ((digest[offset + 2] & 0xff) << 8) | (digest[offset + 3] & 0xff);
    return String(binary % (10 ** digits)).padStart(digits, '0');
  }

  function formatCode(code) {
    if (/^\d{6}$/.test(code)) return code.slice(0, 3) + ' ' + code.slice(3);
    if (/^\d{8}$/.test(code)) return code.slice(0, 4) + ' ' + code.slice(4);
    return code;
  }

  window.AuthLiveTOTP = { normaliseSecret, decodeBase32, parseOtpAuth, generateCode, formatCode };

  /* ============ Page wiring (homepage tool only) ============ */
  const secretInput = typeof document !== 'undefined' ? document.querySelector('#secret-key') : null;
  if (!secretInput) return;
  const generateButton = document.querySelector('#generate-button');
  const generatedCode = document.querySelector('.generated-code');
  const copyButton = document.querySelector('.copy-button');
  const status = document.querySelector('.result-status');
  const inputGroup = document.querySelector('.input-group');
  const inputLabel = document.querySelector('.input-label');
  const ringFg = document.querySelector('.ring-fg');
  const countdownNum = document.querySelector('.countdown-num');
  const countdownWrap = document.querySelector('.countdown-wrap');
  const accountName = document.querySelector('.account-name');
  const algSelect = document.querySelector('#totp-algorithm');
  const digitsSelect = document.querySelector('#totp-digits');
  const periodInput = document.querySelector('#totp-period');
  const modeSelect = document.querySelector('#totp-mode');
  const counterInput = document.querySelector('#hotp-counter');
  if (!generateButton || !generatedCode || !copyButton || !status) return;

  const RING_C = 2 * Math.PI * 19;
  if (ringFg) { ringFg.style.strokeDasharray = String(RING_C); ringFg.style.strokeDashoffset = '0'; }

  let state = null;
  let tickTimer = null;
  let debounceTimer = null;
  let lastRecordedSecret = '';
  let copyStatusId = null;

  function toast(msg) {
    let el = document.querySelector('.toast');
    if (!el) { el = document.createElement('div'); el.className = 'toast'; el.setAttribute('role', 'status'); el.setAttribute('aria-live', 'polite'); document.body.appendChild(el); }
    el.textContent = msg;
    el.classList.add('show');
    window.clearTimeout(el._t);
    el._t = window.setTimeout(() => el.classList.remove('show'), 2200);
  }

  function getErrorElement() {
    let el = inputGroup ? inputGroup.querySelector('.totp-error') : null;
    if (el) return el;
    el = document.createElement('p');
    el.className = 'totp-error';
    el.setAttribute('role', 'alert');
    if (inputLabel && inputLabel.parentNode) inputLabel.after(el);
    else if (inputGroup) inputGroup.appendChild(el);
    else secretInput.after(el);
    return el;
  }
  function showError(message) {
    const el = getErrorElement();
    el.textContent = message; el.hidden = false;
    secretInput.classList.add('input-error');
    status.textContent = 'ERROR';
  }
  function clearError() {
    const el = inputGroup ? inputGroup.querySelector('.totp-error') : null;
    if (el) { el.textContent = ''; el.hidden = true; }
    secretInput.classList.remove('input-error');
    if (status.textContent === 'ERROR') status.textContent = 'READY';
  }

  function currentOptions(parsed) {
    const mode = (parsed && parsed.type === 'hotp') ? 'HOTP' : ((modeSelect && modeSelect.value) || 'TOTP');
    return {
      algorithm: (parsed && parsed.algorithm) || (algSelect && algSelect.value) || 'SHA1',
      digits: (parsed && parsed.digits) || parseInt(digitsSelect && digitsSelect.value, 10) || 6,
      period: (parsed && parsed.period) || parseInt(periodInput && periodInput.value, 10) || 30,
      mode,
      hotpCounter: (parsed && typeof parsed.counter === 'number') ? parsed.counter : (parseInt(counterInput && counterInput.value, 10) || 0)
    };
  }

  function stopTick() { if (tickTimer) { window.clearInterval(tickTimer); tickTimer = null; } }

  function renderCountdown() {
    if (!state) return;
    const nowSec = Date.now() / 1000;
    const remaining = state.period - (nowSec % state.period);
    const whole = Math.ceil(remaining);
    if (countdownNum) countdownNum.textContent = String(whole);
    if (ringFg) ringFg.style.strokeDashoffset = String(RING_C * (1 - remaining / state.period));
    if (countdownWrap) countdownWrap.classList.toggle('expiring', remaining <= 5.5);
  }

  async function refreshCode() {
    if (!state) return;
    try {
      const genOpts = { algorithm: state.algorithm, digits: state.digits, period: state.period };
      if (state.mode === 'HOTP') genOpts.counter = state.hotpCounter;
      const code = await generateCode(state.secretNorm, genOpts);
      state.code = code;
      if (state.mode === 'HOTP') {
        // counter-based: show the code for the current counter, then advance
        if (countdownNum) countdownNum.textContent = '–';
        if (ringFg) ringFg.style.strokeDashoffset = '0';
        state.hotpCounter = state.hotpCounter + 1;
        if (counterInput) counterInput.value = String(state.hotpCounter);
      } else {
        state.counter = Math.floor(Date.now() / 1000 / state.period);
      }
      generatedCode.textContent = formatCode(code);
      status.textContent = 'CODE READY';
      copyButton.disabled = false;
      if (state.secretNorm !== lastRecordedSecret) {
        lastRecordedSecret = state.secretNorm;
        window.dispatchEvent(new CustomEvent('totp:generated', { detail: { code } }));
      }
    } catch { /* keep last shown code; next tick retries */ }
  }

  function startTick() {
    stopTick();
    if (state && state.mode === 'HOTP') return;
    renderCountdown();
    tickTimer = window.setInterval(() => {
      if (!state) return;
      renderCountdown();
      const counter = Math.floor(Date.now() / 1000 / state.period);
      if (counter !== state.counter) refreshCode();
    }, 250);
  }

  async function handleGenerate(fromAuto) {
    clearError();
    if (!window.crypto || !window.crypto.subtle) {
      showError('Secure code generation is unavailable in this browser. Please use the secure HTTPS version of this page.');
      return;
    }
    const raw = secretInput.value;
    if (!raw.trim()) { state = null; stopTick(); generatedCode.textContent = '------'; copyButton.disabled = true; return; }
    try {
      const parsed = parseOtpAuth(raw);
      if (parsed.type === 'hotp') {
        if (modeSelect) modeSelect.value = 'HOTP';
        if (counterInput && typeof parsed.counter === 'number') counterInput.value = String(parsed.counter);
      }
      const secretNorm = normaliseSecret(parsed.secret);
      decodeBase32(secretNorm);
      const opts = currentOptions(parsed);
      if (algSelect && parsed.algorithm) algSelect.value = parsed.algorithm;
      if (digitsSelect && parsed.digits) digitsSelect.value = String(parsed.digits);
      if (periodInput && parsed.period) periodInput.value = String(parsed.period);
      state = { secretNorm, ...opts, counter: -1, code: '' };
      if (accountName) {
        const name = parsed.issuer || parsed.label;
        accountName.textContent = name ? 'Account: ' + name : '';
        accountName.hidden = !name;
      }
      await refreshCode();
      startTick();
      if (!fromAuto) secretInput.focus();
    } catch (error) {
      state = null; stopTick();
      generatedCode.textContent = '------';
      copyButton.disabled = true;
      if (!fromAuto || secretInput.value.trim().length >= 16) {
        showError(error instanceof Error ? error.message : 'Could not generate a code. Please check your secret key and try again.');
      }
    }
  }

  async function handleCopy() {
    if (!state || !state.code) return;
    try { await navigator.clipboard.writeText(state.code); }
    catch {
      const ta = document.createElement('textarea');
      ta.value = state.code; document.body.appendChild(ta); ta.select();
      try { document.execCommand('copy'); } catch { /* ignore */ }
      ta.remove();
    }
    status.textContent = 'COPIED';
    toast('Code copied ✓');
    if (copyStatusId) window.clearTimeout(copyStatusId);
    copyStatusId = window.setTimeout(() => { if (status.textContent === 'COPIED') status.textContent = 'CODE READY'; }, 2000);
  }

  generateButton.addEventListener('click', () => handleGenerate(false));
  copyButton.addEventListener('click', handleCopy);
  generatedCode.addEventListener('click', handleCopy);
  secretInput.addEventListener('input', () => {
    clearError();
    window.clearTimeout(debounceTimer);
    debounceTimer = window.setTimeout(() => handleGenerate(true), 400);
  });
  [algSelect, digitsSelect, periodInput, modeSelect, counterInput].forEach((el) => {
    if (el) el.addEventListener('change', () => { if (secretInput.value.trim()) handleGenerate(true); });
  });

  const toggleBtn = document.querySelector('#toggle-secret');
  if (toggleBtn) {
    toggleBtn.addEventListener('click', () => {
      const masked = secretInput.type === 'password';
      secretInput.type = masked ? 'text' : 'password';
      toggleBtn.textContent = masked ? 'Hide' : 'Show';
      toggleBtn.setAttribute('aria-pressed', String(!masked));
    });
  }

  /* ============ QR scanning (camera + image upload, fully local) ============ */
  async function getDetector() {
    if (!('BarcodeDetector' in window)) return null;
    try { return new window.BarcodeDetector({ formats: ['qr_code'] }); }
    catch { return null; }
  }
  function applyQrText(text) {
    secretInput.value = text;
    secretInput.dispatchEvent(new Event('input', { bubbles: true }));
    toast('QR code read ✓');
  }

  const uploadBtn = document.querySelector('#upload-qr-button');
  const fileInput = document.querySelector('#qr-file-input');
  if (uploadBtn && fileInput) {
    uploadBtn.addEventListener('click', () => fileInput.click());
    fileInput.addEventListener('change', async () => {
      const file = fileInput.files && fileInput.files[0];
      fileInput.value = '';
      if (!file) return;
      const detector = await getDetector();
      if (!detector) { toast('QR image reading is not supported in this browser. Please paste the key instead.'); return; }
      try {
        const bitmap = await createImageBitmap(file);
        const results = await detector.detect(bitmap);
        if (results && results.length && results[0].rawValue) applyQrText(results[0].rawValue);
        else toast('No QR code found in that image.');
      } catch { toast('Could not read that image. Please try another one.'); }
    });
  }

  const scanBtn = document.querySelector('#scan-qr-button');
  if (scanBtn) {
    scanBtn.addEventListener('click', async () => {
      const detector = await getDetector();
      if (!detector || !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        toast('Camera QR scanning is not supported in this browser. Use "Upload QR image" or paste the key.');
        return;
      }
      let stream = null;
      const modal = document.createElement('div');
      modal.className = 'qr-modal';
      modal.innerHTML = '<div class="qr-box"><video class="qr-video" autoplay playsinline muted></video><p>Point your camera at the QR code</p><button type="button" class="qr-close">Cancel</button></div>';
      document.body.appendChild(modal);
      const video = modal.querySelector('.qr-video');
      const close = () => { if (stream) stream.getTracks().forEach((t) => t.stop()); modal.remove(); };
      modal.querySelector('.qr-close').addEventListener('click', close);
      try {
        stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
        video.srcObject = stream;
        const loop = async () => {
          if (!document.body.contains(modal)) return;
          try {
            const results = await detector.detect(video);
            if (results && results.length && results[0].rawValue) { const v = results[0].rawValue; close(); applyQrText(v); return; }
          } catch { /* keep scanning */ }
          window.setTimeout(loop, 350);
        };
        loop();
      } catch { close(); toast('Camera access was blocked. Use "Upload QR image" or paste the key.'); }
    });
  }
})();
