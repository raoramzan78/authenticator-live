(() => {
  const generateButton = document.querySelector('#generate-button');
  const generatedCode = document.querySelector('.generated-code');
  if (!generateButton || !generatedCode) return;

  const STORAGE_KEY = 'authlive.codeHistory.v1';
  const MAX_ITEMS = 10;
  const MAX_AGE_MS = 24 * 60 * 60 * 1000;

  function loadHistory() {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (!raw) return [];
      const items = JSON.parse(raw);
      if (!Array.isArray(items)) return [];
      const cutoff = Date.now() - MAX_AGE_MS;
      return items.filter((i) => i && /^\d{6,8}$/.test(i.code) && i.t > cutoff).slice(0, MAX_ITEMS);
    } catch {
      return [];
    }
  }

  function saveHistory(items) {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(items.slice(0, MAX_ITEMS)));
    } catch {
      /* storage unavailable (private mode etc.) — history simply won't persist */
    }
  }

  // ---- Build the side History button + slide-over panel ----
  const toggle = document.createElement('button');
  toggle.type = 'button';
  toggle.className = 'history-toggle';
  toggle.setAttribute('aria-expanded', 'false');
  toggle.setAttribute('aria-controls', 'history-panel');
  toggle.innerHTML = '<span class="history-toggle-icon" aria-hidden="true">&#8635;</span><span>History</span>';

  const panel = document.createElement('aside');
  panel.className = 'history-panel';
  panel.id = 'history-panel';
  panel.setAttribute('aria-label', 'Recently generated codes');
  panel.innerHTML =
    '<div class="history-panel-head">' +
    '<h2>Recent codes</h2>' +
    '<button type="button" class="history-close" aria-label="Close history">&times;</button>' +
    '</div>' +
    '<p class="history-note">Saved only in this browser, on this device — each entry keeps the authenticator name, its secret key and the code together, so you can use them again without typing the key again. Nothing is ever sent to a server. Codes expire about 30 seconds after they are generated.</p>' +
    '<ul class="history-list"></ul>' +
    '<p class="history-empty">No codes yet. Generate a code and it will appear here, even after you refresh the page.</p>' +
    '<button type="button" class="history-clear">Clear history</button>';

  document.body.appendChild(toggle);
  document.body.appendChild(panel);

  const list = panel.querySelector('.history-list');
  const emptyNote = panel.querySelector('.history-empty');
  const clearButton = panel.querySelector('.history-clear');
  const closeButton = panel.querySelector('.history-close');

  function formatTime(t) {
    try {
      return new Date(t).toLocaleString([], { hour: '2-digit', minute: '2-digit', month: 'short', day: 'numeric' });
    } catch {
      return '';
    }
  }

  function render() {
    const items = loadHistory();
    list.innerHTML = '';
    emptyNote.style.display = items.length ? 'none' : '';
    clearButton.style.display = items.length ? '' : 'none';
    toggle.classList.toggle('has-history', items.length > 0);
    items.forEach((item) => {
      const li = document.createElement('li');
      li.className = 'history-item';
      const code = document.createElement('button');
      code.type = 'button';
      code.className = 'history-code';
      code.textContent = item.code;
      code.title = 'Copy this code';
      code.addEventListener('click', async () => {
        try {
          await navigator.clipboard.writeText(item.code);
          code.textContent = 'Copied \u2713';
          window.setTimeout(() => { code.textContent = item.code; }, 1200);
        } catch { /* clipboard unavailable */ }
      });
      const time = document.createElement('span');
      time.className = 'history-time';
      time.textContent = formatTime(item.t);
      const main = document.createElement('div');
      main.className = 'history-main';
      const label = document.createElement('span');
      label.className = 'history-label';
      label.textContent = item.label || 'Authenticator';
      main.appendChild(label);
      main.appendChild(code);
      if (item.key) {
        const keyBtn = document.createElement('button');
        keyBtn.type = 'button';
        keyBtn.className = 'history-key';
        keyBtn.textContent = 'Key: ' + item.key;
        keyBtn.title = 'Copy this secret key';
        keyBtn.addEventListener('click', async () => {
          try {
            await navigator.clipboard.writeText(item.key);
            keyBtn.textContent = 'Key copied';
            window.setTimeout(() => { keyBtn.textContent = 'Key: ' + item.key; }, 1200);
          } catch { /* clipboard unavailable */ }
        });
        main.appendChild(keyBtn);
      }
      const side = document.createElement('div');
      side.className = 'history-side';
      side.appendChild(time);
      if (item.key) {
        const regen = document.createElement('button');
        regen.type = 'button';
        regen.className = 'history-regen';
        regen.textContent = '\u21bb New code';
        regen.title = 'Generate a fresh code from this saved key';
        regen.addEventListener('click', () => {
          const input = document.querySelector('#secret-key');
          if (!input) return;
          input.value = item.key;
          input.dispatchEvent(new Event('input', { bubbles: true }));
          setOpen(false);
          generateButton.click();
          window.scrollTo({ top: 0, behavior: 'smooth' });
        });
        side.appendChild(regen);
      }
      li.appendChild(main);
      li.appendChild(side);
      list.appendChild(li);
    });
  }

  function setOpen(open) {
    panel.classList.toggle('open', open);
    toggle.setAttribute('aria-expanded', String(open));
    if (open) render();
  }

  toggle.addEventListener('click', () => setOpen(!panel.classList.contains('open')));
  closeButton.addEventListener('click', () => setOpen(false));
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') setOpen(false); });
  clearButton.addEventListener('click', () => { saveHistory([]); render(); });

  // ---- Work out which authenticator a code belongs to (name only — never the key) ----
  function authenticatorName() {
    const input = document.querySelector('#secret-key');
    const raw = ((input && input.value) || '').trim();
    if (/^otpauth:\/\//i.test(raw)) {
      try {
        const u = new URL(raw);
        const issuer = u.searchParams.get('issuer');
        if (issuer) return issuer.slice(0, 40);
        const pathLabel = decodeURIComponent(u.pathname).replace(/^\/+/, '');
        const name = (pathLabel.split(':')[0] || '').trim();
        if (name) return name.slice(0, 40);
      } catch { /* fall through to page-based name */ }
    }
    const p = window.location.pathname;
    if (p.includes('amazon')) return 'Amazon';
    if (p.includes('facebook')) return 'Facebook';
    if (p.includes('binance')) return 'Binance';
    if (p.includes('google')) return 'Google';
    return 'Authenticator';
  }

  // ---- Extract the secret key exactly as the generator used it ----
  function secretKey() {
    const input = document.querySelector('#secret-key');
    const raw = ((input && input.value) || '').trim();
    if (!raw) return '';
    let candidate = raw;
    if (/^otpauth:\/\//i.test(raw)) {
      try {
        const s = new URL(raw).searchParams.get('secret');
        if (!s) return '';
        candidate = s;
      } catch { return ''; }
    }
    const normalised = candidate.replace(/[\s-]/g, '').toUpperCase();
    if (!/^[A-Z2-7]{16,}={0,6}$/.test(normalised)) return '';
    return normalised;
  }

  // ---- Record each successfully generated code ----
  function recordCurrent() {
    const code = (generatedCode.textContent || '').replace(/\s/g, '').trim();
    if (!/^\d{6,8}$/.test(code)) return;
    const items = loadHistory();
    const last = items[0];
    if (last && last.code === code && Date.now() - last.t < 30000) return;
    items.unshift({ code, t: Date.now(), label: authenticatorName(), key: secretKey() });
    saveHistory(items);
    render();
  }
  generateButton.addEventListener('click', () => {
    window.setTimeout(recordCurrent, 450);
  });
  // Auto-generated codes (v20: code appears as soon as a key is pasted)
  window.addEventListener('totp:generated', () => {
    window.setTimeout(recordCurrent, 60);
  });

  render();
})();
